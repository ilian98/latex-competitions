# latex-competitions
Latex structure and examples for the template of the national competitions. The two examples are a standard batch type task and an interactive task.
